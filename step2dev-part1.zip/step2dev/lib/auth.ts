import jwt from 'jsonwebtoken'
import { cookies } from 'next/headers'
import { prisma } from './prisma'

const JWT_SECRET = process.env.JWT_SECRET!
const JWT_EXPIRES_IN = process.env.JWT_EXPIRES_IN || '7d'
const COOKIE_NAME = 'step2dev_token'

// ─── TYPES ───────────────────────────────────────────────────────────────────

export interface JWTPayload {
  userId: string
  email: string
  sessionId: string
  iat?: number
  exp?: number
}

export interface AuthUser {
  id: string
  name: string
  email: string
  emailVerified: boolean
  plan: string
  avatarUrl: string | null
}

// ─── TOKEN ───────────────────────────────────────────────────────────────────

export function signToken(payload: Omit<JWTPayload, 'iat' | 'exp'>): string {
  return jwt.sign(payload, JWT_SECRET, { expiresIn: JWT_EXPIRES_IN } as jwt.SignOptions)
}

export function verifyToken(token: string): JWTPayload | null {
  try {
    return jwt.verify(token, JWT_SECRET) as JWTPayload
  } catch {
    return null
  }
}

// ─── COOKIE ──────────────────────────────────────────────────────────────────

export function setAuthCookie(token: string) {
  const cookieStore = cookies()
  cookieStore.set(COOKIE_NAME, token, {
    httpOnly: true,
    secure: process.env.NODE_ENV === 'production',
    sameSite: 'lax',
    maxAge: 60 * 60 * 24 * 7, // 7 days
    path: '/',
  })
}

export function clearAuthCookie() {
  const cookieStore = cookies()
  cookieStore.set(COOKIE_NAME, '', {
    httpOnly: true,
    secure: process.env.NODE_ENV === 'production',
    sameSite: 'lax',
    maxAge: 0,
    path: '/',
  })
}

export function getTokenFromCookie(): string | null {
  const cookieStore = cookies()
  return cookieStore.get(COOKIE_NAME)?.value ?? null
}

// ─── SESSION ─────────────────────────────────────────────────────────────────

export async function createSession(
  userId: string,
  token: string,
  meta?: { userAgent?: string; ipAddress?: string }
) {
  const expiresAt = new Date(Date.now() + 7 * 24 * 60 * 60 * 1000)
  return prisma.session.create({
    data: {
      userId,
      token,
      expiresAt,
      userAgent: meta?.userAgent,
      ipAddress: meta?.ipAddress,
    },
  })
}

export async function invalidateSession(token: string) {
  await prisma.session.deleteMany({ where: { token } })
}

export async function invalidateAllSessions(userId: string) {
  await prisma.session.deleteMany({ where: { userId } })
}

// ─── GET CURRENT USER ────────────────────────────────────────────────────────

export async function getCurrentUser(): Promise<AuthUser | null> {
  const token = getTokenFromCookie()
  if (!token) return null

  const payload = verifyToken(token)
  if (!payload) return null

  // Verify session is still valid in DB
  const session = await prisma.session.findUnique({
    where: { token },
    include: { user: true },
  })

  if (!session || session.expiresAt < new Date()) {
    return null
  }

  const { user } = session
  return {
    id: user.id,
    name: user.name,
    email: user.email,
    emailVerified: user.emailVerified,
    plan: user.plan,
    avatarUrl: user.avatarUrl,
  }
}

// ─── REQUIRE AUTH (for server components / API routes) ────────────────────────

export async function requireAuth(): Promise<AuthUser> {
  const user = await getCurrentUser()
  if (!user) {
    throw new Error('UNAUTHORIZED')
  }
  return user
}
