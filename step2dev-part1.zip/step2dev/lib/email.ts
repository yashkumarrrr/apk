// lib/email.ts
// Primary: Resend API | Fallback: SMTP via Nodemailer

const APP_URL = process.env.NEXT_PUBLIC_APP_URL || 'http://localhost:3000'
const FROM = process.env.EMAIL_FROM || 'AccIQ <noreply@step2dev.com>'

interface SendEmailOptions {
  to: string
  subject: string
  html: string
  text?: string
}

// ─── SEND VIA RESEND ─────────────────────────────────────────────────────────

async function sendViaResend(opts: SendEmailOptions): Promise<void> {
  const { Resend } = await import('resend')
  const resend = new Resend(process.env.RESEND_API_KEY)

  const { error } = await resend.emails.send({
    from: FROM,
    to: opts.to,
    subject: opts.subject,
    html: opts.html,
    text: opts.text,
  })

  if (error) throw new Error(`Resend error: ${error.message}`)
}

// ─── SEND VIA NODEMAILER (SMTP fallback) ─────────────────────────────────────

async function sendViaSMTP(opts: SendEmailOptions): Promise<void> {
  const nodemailer = await import('nodemailer')

  const transporter = nodemailer.createTransport({
    host: process.env.SMTP_HOST,
    port: Number(process.env.SMTP_PORT) || 587,
    secure: false,
    auth: {
      user: process.env.SMTP_USER,
      pass: process.env.SMTP_PASS,
    },
  })

  await transporter.sendMail({
    from: FROM,
    to: opts.to,
    subject: opts.subject,
    html: opts.html,
    text: opts.text,
  })
}

// ─── MAIN SEND FUNCTION ──────────────────────────────────────────────────────

export async function sendEmail(opts: SendEmailOptions): Promise<void> {
  try {
    if (process.env.RESEND_API_KEY) {
      await sendViaResend(opts)
    } else if (process.env.SMTP_HOST) {
      await sendViaSMTP(opts)
    } else {
      // Dev mode: log to console
      console.log('\n📧 EMAIL (dev mode — no provider configured):')
      console.log('  To:', opts.to)
      console.log('  Subject:', opts.subject)
      console.log('  ---')
      console.log(opts.text || '[HTML email]')
      console.log('---\n')
    }
  } catch (err) {
    console.error('❌ Failed to send email:', err)
    throw err
  }
}

// ─── EMAIL TEMPLATES ─────────────────────────────────────────────────────────

export function buildVerifyEmailHtml(name: string, token: string): string {
  const link = `${APP_URL}/auth/verify-email?token=${token}`
  return `
<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Verify your email</title>
</head>
<body style="margin:0;padding:0;background:#080c10;font-family:'Courier New',monospace;color:#e6edf3;">
  <table width="100%" cellpadding="0" cellspacing="0" style="padding:40px 20px;">
    <tr><td align="center">
      <table width="520" cellpadding="0" cellspacing="0" style="background:#0d1117;border:1px solid #30363d;border-radius:16px;padding:48px 40px;">
        <tr><td>
          <h1 style="font-family:Georgia,serif;font-size:36px;font-weight:900;margin:0 0 8px;letter-spacing:-1px;">AccIQ V1.0</h1>
          <p style="color:#7d8590;font-size:11px;letter-spacing:4px;text-transform:uppercase;margin:0 0 40px;">CLAIM YOUR SPOT</p>
          <p style="font-size:15px;line-height:1.7;margin:0 0 12px;">Hey <strong>${name}</strong>,</p>
          <p style="font-size:14px;line-height:1.7;color:#7d8590;margin:0 0 32px;">
            You're almost in. Verify your email to activate your AccIQ account and start automating your DevOps workflow.
          </p>
          <a href="${link}" style="display:inline-block;background:#2563eb;color:#ffffff;text-decoration:none;font-size:12px;font-weight:700;letter-spacing:3px;text-transform:uppercase;padding:16px 36px;border-radius:10px;">
            VERIFY EMAIL
          </a>
          <p style="font-size:12px;color:#7d8590;margin:32px 0 0;">
            This link expires in <strong style="color:#e6edf3;">24 hours</strong>.<br>
            If you didn't create an account, you can safely ignore this email.
          </p>
          <hr style="border:none;border-top:1px solid #30363d;margin:32px 0;">
          <p style="font-size:11px;color:#7d8590;margin:0;">
            Or copy this link: <a href="${link}" style="color:#3b82f6;">${link}</a>
          </p>
        </td></tr>
      </table>
    </td></tr>
  </table>
</body>
</html>`
}

export function buildVerifyEmailText(name: string, token: string): string {
  const link = `${APP_URL}/auth/verify-email?token=${token}`
  return `
AccIQ V1.0 — Verify Your Email

Hey ${name},

Verify your email to activate your AccIQ account:
${link}

This link expires in 24 hours.
If you didn't create an account, ignore this email.
`
}

export function buildPasswordResetHtml(name: string, token: string): string {
  const link = `${APP_URL}/auth/reset-password?token=${token}`
  return `
<!DOCTYPE html>
<html>
<body style="margin:0;padding:0;background:#080c10;font-family:'Courier New',monospace;color:#e6edf3;">
  <table width="100%" cellpadding="0" cellspacing="0" style="padding:40px 20px;">
    <tr><td align="center">
      <table width="520" cellpadding="0" cellspacing="0" style="background:#0d1117;border:1px solid #30363d;border-radius:16px;padding:48px 40px;">
        <tr><td>
          <h1 style="font-family:Georgia,serif;font-size:36px;font-weight:900;margin:0 0 40px;">AccIQ V1.0</h1>
          <p style="font-size:15px;margin:0 0 12px;">Hey <strong>${name}</strong>,</p>
          <p style="font-size:14px;color:#7d8590;margin:0 0 32px;">
            We received a request to reset your password. Click below to set a new one.
          </p>
          <a href="${link}" style="display:inline-block;background:#2563eb;color:#fff;text-decoration:none;font-size:12px;font-weight:700;letter-spacing:3px;padding:16px 36px;border-radius:10px;">
            RESET PASSWORD
          </a>
          <p style="font-size:12px;color:#7d8590;margin:32px 0 0;">
            Expires in <strong style="color:#e6edf3;">1 hour</strong>. If you didn't request this, ignore this email.
          </p>
        </td></tr>
      </table>
    </td></tr>
  </table>
</body>
</html>`
}
