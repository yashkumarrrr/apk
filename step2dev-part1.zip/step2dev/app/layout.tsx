import type { Metadata } from 'next'
import { Syne, JetBrains_Mono } from 'next/font/google'
import './globals.css'

const syne = Syne({
  subsets: ['latin'],
  weight: ['400', '700', '800'],
  variable: '--font-display',
  display: 'swap',
})

const jetbrainsMono = JetBrains_Mono({
  subsets: ['latin'],
  weight: ['300', '400', '500'],
  variable: '--font-mono',
  display: 'swap',
})

export const metadata: Metadata = {
  title: 'AccIQ V1.0 | DevOps IDE',
  description: 'The all-in-one DevOps platform — CI/CD, monitoring, server management, and more.',
  keywords: ['devops', 'cicd', 'monitoring', 'server management', 'cloud'],
  openGraph: {
    title: 'AccIQ V1.0',
    description: 'Your all-in-one DevOps IDE',
    type: 'website',
  },
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="en" className={`${syne.variable} ${jetbrainsMono.variable}`}>
      <body className="bg-bg text-white font-mono antialiased">
        {children}
      </body>
    </html>
  )
}
