import { getCurrentUser } from '@/lib/auth'
import { redirect } from 'next/navigation'
import Link from 'next/link'

export default async function DashboardPage() {
  const user = await getCurrentUser()

  if (!user) {
    redirect('/auth/login?from=/dashboard')
  }

  return (
    <div className="min-h-screen bg-bg text-white font-mono">
      {/* Top bar */}
      <header className="bg-surface border-b border-border px-6 py-4 flex items-center justify-between">
        <span className="font-display font-black text-lg tracking-tight">AccIQ V1.0</span>
        <div className="flex items-center gap-4">
          {!user.emailVerified && (
            <div className="bg-warning/10 border border-warning/30 rounded-lg px-3 py-1.5 text-xs text-warning flex items-center gap-2">
              ⚠ Please verify your email
            </div>
          )}
          <div className="bg-surface-2 border border-border rounded-full px-4 py-1.5 text-xs text-muted">
            {user.name}
          </div>
          <form action="/api/auth/logout" method="POST">
            <button
              type="submit"
              className="text-xs text-muted hover:text-white transition-colors"
            >
              Sign out
            </button>
          </form>
        </div>
      </header>

      {/* Main */}
      <main className="max-w-5xl mx-auto px-6 py-16">
        <div className="mb-12">
          <h1 className="font-display font-black text-4xl mb-3">
            Welcome, {user.name.split(' ')[0]} 👋
          </h1>
          <p className="text-muted text-sm">
            Your DevOps command center. Part 2 (Projects + full dashboard) coming next.
          </p>
        </div>

        {/* Feature cards */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {[
            { icon: '⚡', title: 'CI/CD Pipelines', desc: 'Automate builds, tests, and deploys', status: 'Part 3', href: '#' },
            { icon: '📊', title: 'Monitoring', desc: 'Real-time system health & logs', status: 'Part 5', href: '#' },
            { icon: '🖥️', title: 'Server Management', desc: 'Control your infrastructure', status: 'Part 4', href: '#' },
            { icon: '☁️', title: 'AWS Integration', desc: 'EC2, S3, RDS in one place', status: 'Part 6', href: '#' },
            { icon: '🤖', title: 'AI Automation', desc: 'Let AI handle repetitive tasks', status: 'Part 7', href: '#' },
            { icon: '🔔', title: 'Alerts', desc: 'Never miss a critical event', status: 'Part 5', href: '#' },
          ].map((f) => (
            <div
              key={f.title}
              className="bg-surface border border-border rounded-xl p-5 hover:border-accent/50 transition-colors cursor-pointer group"
            >
              <div className="text-2xl mb-3">{f.icon}</div>
              <h3 className="font-display font-bold text-base mb-1 group-hover:text-accent-2 transition-colors">
                {f.title}
              </h3>
              <p className="text-muted text-xs mb-3">{f.desc}</p>
              <span className="text-[10px] tracking-[1px] text-muted border border-border rounded px-2 py-0.5 uppercase">
                {f.status}
              </span>
            </div>
          ))}
        </div>

        {/* User info */}
        <div className="mt-12 bg-surface border border-border rounded-xl p-6">
          <h2 className="font-display font-bold text-lg mb-4">Your Account</h2>
          <div className="grid grid-cols-2 gap-4 text-sm">
            <div>
              <p className="text-muted text-xs mb-1 uppercase tracking-wide">Name</p>
              <p>{user.name}</p>
            </div>
            <div>
              <p className="text-muted text-xs mb-1 uppercase tracking-wide">Email</p>
              <p>{user.email}</p>
            </div>
            <div>
              <p className="text-muted text-xs mb-1 uppercase tracking-wide">Plan</p>
              <p className="text-accent-2 font-bold">{user.plan}</p>
            </div>
            <div>
              <p className="text-muted text-xs mb-1 uppercase tracking-wide">Email Verified</p>
              <p className={user.emailVerified ? 'text-success' : 'text-warning'}>
                {user.emailVerified ? '✓ Verified' : '⚠ Pending'}
              </p>
            </div>
          </div>
        </div>
      </main>
    </div>
  )
}
