import { NextRequest } from 'next/server'
import { getTokenFromCookie, clearAuthCookie, invalidateSession } from '@/lib/auth'
import { apiSuccess } from '@/lib/utils'

export async function POST(_req: NextRequest) {
  const token = getTokenFromCookie()

  if (token) {
    await invalidateSession(token)
  }

  clearAuthCookie()

  return apiSuccess({ message: 'Logged out successfully' })
}
