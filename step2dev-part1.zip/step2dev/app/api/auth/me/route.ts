import { NextRequest } from 'next/server'
import { getCurrentUser } from '@/lib/auth'
import { apiSuccess, apiError } from '@/lib/utils'

export async function GET(_req: NextRequest) {
  const user = await getCurrentUser()

  if (!user) {
    return apiError('Not authenticated', 401)
  }

  return apiSuccess({ user })
}
