import { NextRequest } from 'next/server'
import bcrypt from 'bcryptjs'
import { prisma } from '@/lib/prisma'
import { loginSchema } from '@/lib/validations'
import { signToken, createSession, setAuthCookie } from '@/lib/auth'
import { apiSuccess, apiError, getClientIP, getClientUserAgent } from '@/lib/utils'

export async function POST(req: NextRequest) {
  try {
    // ─── Parse & Validate ──────────────────────────────────────────────────
    const body = await req.json()
    const result = loginSchema.safeParse(body)

    if (!result.success) {
      return apiError('Validation failed', 422, result.error.flatten().fieldErrors)
    }

    const { email, password } = result.data

    // ─── Find user ────────────────────────────────────────────────────────
    const user = await prisma.user.findUnique({ where: { email } })

    // Use constant time compare to prevent timing attacks
    const dummyHash = '$2a$12$dummy.hash.to.prevent.timing.attacks.xxxxxxxxx'
    const passwordMatch = user?.passwordHash
      ? await bcrypt.compare(password, user.passwordHash)
      : await bcrypt.compare(password, dummyHash).then(() => false)

    if (!user || !passwordMatch) {
      return apiError('Invalid email or password', 401)
    }

    // ─── Check if OAuth user trying password login ─────────────────────────
    if (user.provider !== 'EMAIL') {
      return apiError(
        `This account uses ${user.provider.toLowerCase()} sign-in. Please use that method.`,
        400
      )
    }

    // ─── Create session ───────────────────────────────────────────────────
    const ip = getClientIP(req)
    const ua = getClientUserAgent(req)

    const tempToken = signToken({ userId: user.id, email: user.email, sessionId: '' })
    const session = await createSession(user.id, tempToken, { ipAddress: ip, userAgent: ua })

    const finalToken = signToken({ userId: user.id, email: user.email, sessionId: session.id })
    await prisma.session.update({ where: { id: session.id }, data: { token: finalToken } })

    setAuthCookie(finalToken)

    // ─── Update lastLoginAt ───────────────────────────────────────────────
    await prisma.user.update({
      where: { id: user.id },
      data: { lastLoginAt: new Date() },
    })

    return apiSuccess({
      user: {
        id: user.id,
        name: user.name,
        email: user.email,
        emailVerified: user.emailVerified,
        plan: user.plan,
        avatarUrl: user.avatarUrl,
      },
      message: 'Logged in successfully',
    })
  } catch (err) {
    console.error('Login error:', err)
    return apiError('Internal server error', 500)
  }
}
