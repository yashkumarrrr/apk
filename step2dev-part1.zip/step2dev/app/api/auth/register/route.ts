import { NextRequest } from 'next/server'
import bcrypt from 'bcryptjs'
import { prisma } from '@/lib/prisma'
import { registerSchema } from '@/lib/validations'
import { signToken, createSession, setAuthCookie } from '@/lib/auth'
import { sendEmail, buildVerifyEmailHtml, buildVerifyEmailText } from '@/lib/email'
import { generateToken, tokenExpiry, apiSuccess, apiError, getClientIP, getClientUserAgent } from '@/lib/utils'

export async function POST(req: NextRequest) {
  try {
    // ─── Parse & Validate ──────────────────────────────────────────────────
    const body = await req.json()
    const result = registerSchema.safeParse(body)

    if (!result.success) {
      const errors = result.error.flatten().fieldErrors
      return apiError('Validation failed', 422, errors)
    }

    const { name, email, password } = result.data

    // ─── Check duplicate email ────────────────────────────────────────────
    const existing = await prisma.user.findUnique({ where: { email } })
    if (existing) {
      return apiError('An account with this email already exists', 409)
    }

    // ─── Hash password ────────────────────────────────────────────────────
    const passwordHash = await bcrypt.hash(password, 12)

    // ─── Generate verify token ────────────────────────────────────────────
    const verifyToken = generateToken(64)
    const verifyTokenExp = tokenExpiry(24) // 24 hours

    // ─── Create user ──────────────────────────────────────────────────────
    const user = await prisma.user.create({
      data: {
        name,
        email,
        passwordHash,
        verifyToken,
        verifyTokenExp,
        emailVerified: false,
        plan: 'FREE',
      },
    })

    // ─── Send verification email ──────────────────────────────────────────
    try {
      await sendEmail({
        to: email,
        subject: 'Verify your AccIQ account',
        html: buildVerifyEmailHtml(name, verifyToken),
        text: buildVerifyEmailText(name, verifyToken),
      })
    } catch (emailErr) {
      console.error('Failed to send verification email:', emailErr)
      // Don't fail registration if email fails — user can resend
    }

    // ─── Create session & JWT ─────────────────────────────────────────────
    // We allow login but features requiring email verification will be gated
    const ip = getClientIP(req)
    const ua = getClientUserAgent(req)

    const token = signToken({ userId: user.id, email: user.email, sessionId: '' })

    // Create DB session
    const session = await createSession(user.id, token, { ipAddress: ip, userAgent: ua })

    // Re-sign with sessionId
    const finalToken = signToken({ userId: user.id, email: user.email, sessionId: session.id })
    await prisma.session.update({ where: { id: session.id }, data: { token: finalToken } })

    setAuthCookie(finalToken)

    // ─── Update lastLoginAt ───────────────────────────────────────────────
    await prisma.user.update({
      where: { id: user.id },
      data: { lastLoginAt: new Date() },
    })

    return apiSuccess(
      {
        user: {
          id: user.id,
          name: user.name,
          email: user.email,
          emailVerified: user.emailVerified,
          plan: user.plan,
        },
        message: 'Account created! Please check your email to verify your account.',
      },
      201
    )
  } catch (err) {
    console.error('Register error:', err)
    return apiError('Internal server error', 500)
  }
}
