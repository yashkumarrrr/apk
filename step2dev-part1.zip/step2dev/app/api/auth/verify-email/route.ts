import { NextRequest } from 'next/server'
import { prisma } from '@/lib/prisma'
import { verifyEmailSchema } from '@/lib/validations'
import { isExpired, apiSuccess, apiError } from '@/lib/utils'

export async function POST(req: NextRequest) {
  try {
    const body = await req.json()
    const result = verifyEmailSchema.safeParse(body)

    if (!result.success) {
      return apiError('Token is required', 400)
    }

    const { token } = result.data

    // ─── Find user by token ───────────────────────────────────────────────
    const user = await prisma.user.findUnique({
      where: { verifyToken: token },
    })

    if (!user) {
      return apiError('Invalid or expired verification link', 400)
    }

    if (user.emailVerified) {
      return apiSuccess({ message: 'Email already verified. You can log in.' })
    }

    if (isExpired(user.verifyTokenExp)) {
      return apiError('Verification link has expired. Please request a new one.', 400)
    }

    // ─── Mark verified ────────────────────────────────────────────────────
    await prisma.user.update({
      where: { id: user.id },
      data: {
        emailVerified: true,
        verifyToken: null,
        verifyTokenExp: null,
      },
    })

    return apiSuccess({ message: 'Email verified successfully! You can now log in.' })
  } catch (err) {
    console.error('Verify email error:', err)
    return apiError('Internal server error', 500)
  }
}

// GET /api/auth/verify-email?token=xxx (for email link clicks)
export async function GET(req: NextRequest) {
  const token = req.nextUrl.searchParams.get('token')
  if (!token) {
    return Response.redirect(
      new URL('/auth/verify-email?error=missing_token', req.url)
    )
  }

  const user = await prisma.user.findUnique({ where: { verifyToken: token } })

  if (!user || isExpired(user.verifyTokenExp)) {
    return Response.redirect(
      new URL('/auth/verify-email?error=invalid_token', req.url)
    )
  }

  await prisma.user.update({
    where: { id: user.id },
    data: { emailVerified: true, verifyToken: null, verifyTokenExp: null },
  })

  return Response.redirect(new URL('/auth/verify-email?success=true', req.url))
}
