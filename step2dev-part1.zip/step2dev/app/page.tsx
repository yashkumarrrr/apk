'use client'

import { useRouter } from 'next/navigation'

export default function LandingPage() {
  const router = useRouter()

  return (
    <main className="relative min-h-screen flex items-center justify-center overflow-hidden bg-bg">
      {/* Grid background */}
      <div className="absolute inset-0 grid-bg pointer-events-none" />

      {/* Glow orb */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[700px] h-[700px] bg-accent/10 rounded-full blur-[120px] pointer-events-none animate-pulse-slow" />

      {/* Content */}
      <div className="relative z-10 w-full max-w-[480px] mx-auto px-6 text-center">
        {/* Logo */}
        <h1 className="font-display font-black text-[clamp(52px,12vw,88px)] leading-none tracking-tight mb-3 animate-fade-up animate-fill-both">
          AccIQ V1.0
        </h1>
        <p className="text-muted text-[11px] tracking-[6px] uppercase mb-14 animate-fade-up animate-delay-100 animate-fill-both">
          Claim Your Spot
        </p>

        {/* Form — redirect to register */}
        <div className="space-y-3 animate-fade-up animate-delay-200 animate-fill-both">
          <button
            onClick={() => router.push('/auth/register')}
            className="w-full py-[18px] bg-accent hover:bg-accent-2 text-white font-display font-bold text-[13px] tracking-[3px] uppercase rounded-xl transition-all duration-200 hover:shadow-[0_8px_24px_rgba(37,99,235,0.35)] hover:-translate-y-0.5 active:translate-y-0"
          >
            Save Spot
          </button>
          <button
            onClick={() => router.push('/auth/login')}
            className="w-full py-4 bg-transparent border border-border text-muted hover:border-accent hover:text-accent-2 font-mono text-[11px] tracking-[3px] uppercase rounded-xl transition-all duration-200"
          >
            Enter via Guest Mode
          </button>
        </div>

        {/* Features teaser */}
        <div className="mt-16 grid grid-cols-2 gap-3 text-left animate-fade-up animate-delay-400 animate-fill-both">
          {[
            { icon: '⚡', label: 'CI/CD Pipelines' },
            { icon: '📊', label: 'Real-time Monitoring' },
            { icon: '🖥️', label: 'Server Management' },
            { icon: '☁️', label: 'AWS Integration' },
            { icon: '🤖', label: 'AI Automation' },
            { icon: '🔔', label: 'Smart Alerts' },
          ].map((f) => (
            <div
              key={f.label}
              className="flex items-center gap-2.5 bg-surface border border-border rounded-lg px-3 py-2.5"
            >
              <span className="text-base">{f.icon}</span>
              <span className="text-[11px] text-muted">{f.label}</span>
            </div>
          ))}
        </div>
      </div>
    </main>
  )
}
