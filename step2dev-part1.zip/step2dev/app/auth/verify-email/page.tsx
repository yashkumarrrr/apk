'use client'

import { useEffect, useState, Suspense } from 'react'
import { useSearchParams, useRouter } from 'next/navigation'
import Link from 'next/link'
import { AuthCard } from '@/components/auth/AuthCard'
import { Button } from '@/components/ui/Button'

type State = 'loading' | 'success' | 'error' | 'pending'

function VerifyEmailContent() {
  const searchParams = useSearchParams()
  const router = useRouter()
  const [state, setState] = useState<State>('loading')
  const [message, setMessage] = useState('')

  useEffect(() => {
    const success = searchParams.get('success')
    const error = searchParams.get('error')
    const token = searchParams.get('token')

    if (success === 'true') {
      setState('success')
      setTimeout(() => router.push('/dashboard'), 2500)
      return
    }

    if (error) {
      setState('error')
      setMessage(
        error === 'missing_token'
          ? 'Verification token is missing.'
          : 'This link is invalid or has expired.'
      )
      return
    }

    if (token) {
      // POST to verify
      fetch('/api/auth/verify-email', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ token }),
      })
        .then((r) => r.json())
        .then((data) => {
          if (data.success) {
            setState('success')
            setTimeout(() => router.push('/dashboard'), 2500)
          } else {
            setState('error')
            setMessage(data.error || 'Verification failed')
          }
        })
        .catch(() => {
          setState('error')
          setMessage('Network error. Please try again.')
        })
      return
    }

    // No token — show pending state
    setState('pending')
  }, [searchParams, router])

  if (state === 'loading') {
    return (
      <AuthCard title="Verifying your email…">
        <div className="flex justify-center py-8">
          <div className="w-10 h-10 border-2 border-border border-t-accent rounded-full animate-spin" />
        </div>
      </AuthCard>
    )
  }

  if (state === 'success') {
    return (
      <AuthCard title="Email verified! 🎉">
        <div className="text-center py-4">
          <div className="w-20 h-20 bg-success/10 border border-success/30 rounded-full flex items-center justify-center mx-auto mb-4 text-4xl">
            ✅
          </div>
          <p className="text-muted text-sm mb-1">Your account is now active.</p>
          <p className="text-muted text-xs">Redirecting to dashboard…</p>
        </div>
      </AuthCard>
    )
  }

  if (state === 'error') {
    return (
      <AuthCard title="Verification failed">
        <div className="text-center py-4">
          <div className="w-20 h-20 bg-danger/10 border border-danger/30 rounded-full flex items-center justify-center mx-auto mb-4 text-4xl">
            ❌
          </div>
          <p className="text-muted text-sm mb-6">{message}</p>
          <Link href="/auth/login">
            <Button variant="primary" fullWidth>Back to Login</Button>
          </Link>
        </div>
      </AuthCard>
    )
  }

  // Pending — waiting for email
  return (
    <AuthCard
      title="Verify your email"
      subtitle="We sent you a verification link. Check your inbox (and spam folder)."
    >
      <div className="text-center py-6">
        <div className="w-20 h-20 bg-accent/10 border border-accent/30 rounded-full flex items-center justify-center mx-auto mb-6 text-4xl">
          ✉️
        </div>
        <p className="text-muted text-sm mb-6">
          Click the link in your email to activate your account. The link expires in 24 hours.
        </p>
        <Link href="/auth/login">
          <Button variant="ghost" fullWidth size="md">
            Back to Sign In
          </Button>
        </Link>
      </div>
    </AuthCard>
  )
}

export default function VerifyEmailPage() {
  return (
    <Suspense fallback={null}>
      <VerifyEmailContent />
    </Suspense>
  )
}
