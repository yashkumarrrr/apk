'use client'

import { useState } from 'react'
import { useRouter } from 'next/navigation'
import Link from 'next/link'
import { AuthCard } from '@/components/auth/AuthCard'
import { Input } from '@/components/ui/Input'
import { Button } from '@/components/ui/Button'

interface FormErrors {
  name?: string[]
  email?: string[]
  password?: string[]
  general?: string
}

export default function RegisterPage() {
  const router = useRouter()
  const [loading, setLoading] = useState(false)
  const [errors, setErrors] = useState<FormErrors>({})
  const [success, setSuccess] = useState(false)

  const [form, setForm] = useState({
    name: '',
    email: '',
    password: '',
  })

  function handleChange(e: React.ChangeEvent<HTMLInputElement>) {
    const { name, value } = e.target
    setForm((prev) => ({ ...prev, [name]: value }))
    // Clear field error on change
    setErrors((prev) => ({ ...prev, [name]: undefined }))
  }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault()
    setLoading(true)
    setErrors({})

    try {
      const res = await fetch('/api/auth/register', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(form),
      })

      const data = await res.json()

      if (!res.ok) {
        if (data.details) {
          setErrors(data.details)
        } else {
          setErrors({ general: data.error || 'Something went wrong' })
        }
        return
      }

      setSuccess(true)
      // Redirect to dashboard after 2s
      setTimeout(() => router.push('/dashboard'), 2000)
    } catch {
      setErrors({ general: 'Network error. Please try again.' })
    } finally {
      setLoading(false)
    }
  }

  if (success) {
    return (
      <AuthCard title="Check your email ✉️" subtitle="">
        <div className="text-center py-4">
          <div className="w-16 h-16 bg-success/10 border border-success/30 rounded-full flex items-center justify-center mx-auto mb-4 text-3xl">
            ✅
          </div>
          <p className="text-muted text-sm leading-relaxed">
            We sent a verification link to{' '}
            <strong className="text-white">{form.email}</strong>.
            Check your inbox and verify your account.
          </p>
          <p className="text-muted text-xs mt-3">Redirecting to dashboard…</p>
        </div>
      </AuthCard>
    )
  }

  return (
    <AuthCard
      title="Create your account"
      subtitle="Join 100+ DevOps engineers on AccIQ"
      footer={
        <p className="text-center text-sm text-muted">
          Already have an account?{' '}
          <Link href="/auth/login" className="text-accent-2 hover:underline">
            Sign in
          </Link>
        </p>
      }
    >
      <form onSubmit={handleSubmit} className="space-y-4">
        {errors.general && (
          <div className="bg-danger/10 border border-danger/30 rounded-lg px-4 py-3 text-sm text-danger flex items-center gap-2">
            <span>⚠</span> {errors.general}
          </div>
        )}

        <Input
          label="Full Name"
          name="name"
          type="text"
          placeholder="Arjun Sharma"
          value={form.name}
          onChange={handleChange}
          error={errors.name?.[0]}
          autoComplete="name"
          required
        />

        <Input
          label="Work Email"
          name="email"
          type="email"
          placeholder="you@company.com"
          value={form.email}
          onChange={handleChange}
          error={errors.email?.[0]}
          autoComplete="email"
          required
        />

        <Input
          label="Password"
          name="password"
          type="password"
          placeholder="Min 8 chars, 1 uppercase, 1 number"
          value={form.password}
          onChange={handleChange}
          error={errors.password?.[0]}
          autoComplete="new-password"
          required
        />

        {/* Password strength hint */}
        {form.password.length > 0 && (
          <PasswordStrength password={form.password} />
        )}

        <Button type="submit" fullWidth size="lg" loading={loading}>
          Save Spot
        </Button>

        <p className="text-center text-[11px] text-muted">
          By registering you agree to our{' '}
          <a href="#" className="text-muted hover:text-white underline">
            Terms
          </a>{' '}
          &amp;{' '}
          <a href="#" className="text-muted hover:text-white underline">
            Privacy Policy
          </a>
        </p>
      </form>
    </AuthCard>
  )
}

function PasswordStrength({ password }: { password: string }) {
  const checks = [
    { label: '8+ characters', ok: password.length >= 8 },
    { label: 'Uppercase letter', ok: /[A-Z]/.test(password) },
    { label: 'Number', ok: /[0-9]/.test(password) },
  ]
  const score = checks.filter((c) => c.ok).length

  const color =
    score === 0 ? 'bg-border'
    : score === 1 ? 'bg-danger'
    : score === 2 ? 'bg-warning'
    : 'bg-success'

  return (
    <div className="space-y-2">
      <div className="flex gap-1.5">
        {[0, 1, 2].map((i) => (
          <div
            key={i}
            className={`h-1 flex-1 rounded-full transition-all duration-300 ${
              i < score ? color : 'bg-border'
            }`}
          />
        ))}
      </div>
      <div className="flex gap-3 flex-wrap">
        {checks.map((c) => (
          <span
            key={c.label}
            className={`text-[11px] flex items-center gap-1 ${
              c.ok ? 'text-success' : 'text-muted'
            }`}
          >
            {c.ok ? '✓' : '○'} {c.label}
          </span>
        ))}
      </div>
    </div>
  )
}
