# AccIQ V1.0 — Step2Dev Platform

> **Part 1: Project Setup & Authentication**

Full-stack Next.js 14 app with JWT auth, email verification, PostgreSQL, and Prisma ORM.

---

## 🚀 Quick Start (5 minutes)

### 1. Install dependencies
```bash
npm install
```

### 2. Set up environment variables
```bash
cp .env.example .env.local
```
Edit `.env.local` with your values (see below).

### 3. Set up the database
```bash
# Push schema to your DB (creates tables)
npx prisma db push

# Generate Prisma client
npx prisma generate

# (Optional) Seed test user
npx ts-node prisma/seed.ts
```

### 4. Run dev server
```bash
npm run dev
```

Open [http://localhost:3000](http://localhost:3000) 🎉

---

## 🔧 Environment Variables

Copy `.env.example` to `.env.local` and fill in:

| Variable | Description | Required |
|---|---|---|
| `DATABASE_URL` | PostgreSQL connection string | ✅ |
| `JWT_SECRET` | Min 32-char secret key | ✅ |
| `NEXT_PUBLIC_APP_URL` | Your app URL | ✅ |
| `RESEND_API_KEY` | Resend.com API key (email) | ✅ (or SMTP) |
| `EMAIL_FROM` | From address for emails | ✅ |

---

## 🗄️ Database Options (Free Tiers)

| Provider | Free Tier | Setup |
|---|---|---|
| **Supabase** | 500MB, 2 projects | [supabase.com](https://supabase.com) → New Project → Settings → Database URL |
| **Neon** | 3GB, unlimited projects | [neon.tech](https://neon.tech) → Create DB → Copy connection string |
| **Railway** | $5 credit/month | [railway.app](https://railway.app) → New → PostgreSQL |
| **PlanetScale** | 5GB free | [planetscale.com](https://planetscale.com) |

---

## 📧 Email Setup

### Option A: Resend (Recommended — Free 3000 emails/month)
1. Sign up at [resend.com](https://resend.com)
2. Create API key
3. Add domain or use `onboarding@resend.dev` for testing
4. Set `RESEND_API_KEY` in `.env.local`

### Option B: Gmail SMTP
```
SMTP_HOST=smtp.gmail.com
SMTP_PORT=587
SMTP_USER=your@gmail.com
SMTP_PASS=your-app-password  # 16-char app password (not Gmail password)
```
Enable 2FA on Gmail → App Passwords → Generate for "Mail"

> **Dev mode:** If no email provider is configured, emails are printed to the console. Perfect for local development.

---

## 🔑 Generate JWT Secret

```bash
# Mac/Linux
openssl rand -base64 64

# Node.js
node -e "console.log(require('crypto').randomBytes(64).toString('base64'))"

# Windows PowerShell
[Convert]::ToBase64String((1..64 | ForEach-Object { Get-Random -Max 256 }))
```

---

## 🌐 Deploy to Vercel (Free)

```bash
# Install Vercel CLI
npm i -g vercel

# Deploy
vercel

# Set environment variables
vercel env add DATABASE_URL
vercel env add JWT_SECRET
vercel env add RESEND_API_KEY
vercel env add EMAIL_FROM
vercel env add NEXT_PUBLIC_APP_URL

# Deploy to production
vercel --prod
```

Or use the Vercel dashboard:
1. Push to GitHub
2. Import repo at [vercel.com](https://vercel.com)
3. Add environment variables in Project Settings → Environment Variables
4. Deploy

---

## 📁 Project Structure

```
step2dev/
├── app/
│   ├── page.tsx                    # Landing page
│   ├── layout.tsx                  # Root layout
│   ├── globals.css                 # Global styles
│   ├── dashboard/
│   │   └── page.tsx                # Dashboard (protected)
│   ├── auth/
│   │   ├── login/page.tsx          # Login page
│   │   ├── register/page.tsx       # Register page
│   │   └── verify-email/page.tsx   # Email verification
│   └── api/
│       ├── auth/
│       │   ├── register/route.ts   # POST /api/auth/register
│       │   ├── login/route.ts      # POST /api/auth/login
│       │   ├── logout/route.ts     # POST /api/auth/logout
│       │   ├── me/route.ts         # GET  /api/auth/me
│       │   └── verify-email/route.ts
│       └── health/route.ts         # GET  /api/health
├── components/
│   ├── ui/
│   │   ├── Button.tsx
│   │   └── Input.tsx
│   └── auth/
│       └── AuthCard.tsx
├── lib/
│   ├── auth.ts                     # JWT + session helpers
│   ├── email.ts                    # Email sending (Resend/SMTP)
│   ├── prisma.ts                   # Prisma singleton
│   ├── utils.ts                    # Utility helpers
│   └── validations.ts              # Zod schemas
├── middleware.ts                   # Auth protection + rate limiting
├── prisma/
│   ├── schema.prisma               # DB schema
│   └── seed.ts                     # Seed test data
├── .env.example                    # Environment template
└── package.json
```

---

## 🔒 Security Features

- ✅ Password hashed with **bcrypt** (cost factor 12)
- ✅ **JWT tokens** stored in httpOnly cookies (XSS-proof)
- ✅ **Session tracking** in DB (revocable)
- ✅ **Rate limiting** — 100 req/min per IP
- ✅ **Timing-safe** password comparison (prevents timing attacks)
- ✅ **Input validation** with Zod (all API routes)
- ✅ **Security headers** (X-Frame-Options, CSP, HSTS in prod)
- ✅ **Email verification** with expiring tokens (24h)
- ✅ Protected routes via **Next.js middleware**

---

## 🧪 Test Credentials (after seeding)

```
Email:    test@step2dev.com
Password: Test1234!
```

---

## 📦 What's in Part 1

| Feature | Status |
|---|---|
| Landing page (AccIQ V1.0) | ✅ |
| User registration + validation | ✅ |
| Email verification | ✅ |
| Login with JWT | ✅ |
| Session management in DB | ✅ |
| Logout | ✅ |
| Protected routes (middleware) | ✅ |
| Rate limiting | ✅ |
| Security headers | ✅ |
| Password strength indicator | ✅ |
| Email templates (HTML + text) | ✅ |
| Dashboard placeholder | ✅ |
| Health check endpoint | ✅ |

---

## ➡️ Next: Part 2 — Dashboard & Multi-Project Support

Coming up:
- Full sidebar dashboard
- Project CRUD (create/list/switch)
- Multi-project isolation
- 100+ user support with DB pooling
