import { NextResponse } from 'next/server'
import type { NextRequest } from 'next/server'
import { verifyToken } from '@/lib/auth'

// Routes that require authentication
const PROTECTED_ROUTES = ['/dashboard', '/projects', '/pipelines', '/servers', '/monitoring']

// Routes only for unauthenticated users
const AUTH_ROUTES = ['/auth/login', '/auth/register', '/auth/verify-email']

// Simple in-memory rate limiter (for edge runtime)
// In production, use Upstash Redis
const rateLimitMap = new Map<string, { count: number; resetAt: number }>()

function rateLimit(ip: string, maxRequests = 100, windowMs = 60_000): boolean {
  const now = Date.now()
  const entry = rateLimitMap.get(ip)

  if (!entry || now > entry.resetAt) {
    rateLimitMap.set(ip, { count: 1, resetAt: now + windowMs })
    return true // allowed
  }

  if (entry.count >= maxRequests) return false // blocked

  entry.count++
  return true // allowed
}

export function middleware(request: NextRequest) {
  const { pathname } = request.nextUrl

  // ─── RATE LIMITING (API routes) ────────────────────────────────────────────
  if (pathname.startsWith('/api/')) {
    const ip =
      request.headers.get('x-forwarded-for')?.split(',')[0].trim() ||
      request.headers.get('x-real-ip') ||
      'anonymous'

    const maxReq = Number(process.env.RATE_LIMIT_MAX) || 100
    const windowMs = Number(process.env.RATE_LIMIT_WINDOW_MS) || 60_000

    if (!rateLimit(ip, maxReq, windowMs)) {
      return NextResponse.json(
        { success: false, error: 'Too many requests. Please slow down.' },
        {
          status: 429,
          headers: {
            'Retry-After': '60',
            'X-RateLimit-Limit': String(maxReq),
          },
        }
      )
    }
  }

  // ─── AUTH CHECKS ────────────────────────────────────────────────────────────
  const token = request.cookies.get('step2dev_token')?.value
  const isAuthenticated = token ? verifyToken(token) !== null : false

  const isProtected = PROTECTED_ROUTES.some((r) => pathname.startsWith(r))
  const isAuthRoute = AUTH_ROUTES.some((r) => pathname.startsWith(r))

  // Redirect unauthenticated users trying to access protected routes
  if (isProtected && !isAuthenticated) {
    const url = request.nextUrl.clone()
    url.pathname = '/auth/login'
    url.searchParams.set('from', pathname)
    return NextResponse.redirect(url)
  }

  // Redirect authenticated users away from auth pages
  if (isAuthRoute && isAuthenticated) {
    const url = request.nextUrl.clone()
    url.pathname = '/dashboard'
    return NextResponse.redirect(url)
  }

  // ─── SECURITY HEADERS ───────────────────────────────────────────────────────
  const response = NextResponse.next()
  response.headers.set('X-Frame-Options', 'DENY')
  response.headers.set('X-Content-Type-Options', 'nosniff')
  response.headers.set('Referrer-Policy', 'strict-origin-when-cross-origin')
  response.headers.set(
    'Permissions-Policy',
    'camera=(), microphone=(), geolocation=()'
  )
  if (process.env.NODE_ENV === 'production') {
    response.headers.set(
      'Strict-Transport-Security',
      'max-age=63072000; includeSubDomains; preload'
    )
  }

  return response
}

export const config = {
  matcher: [
    '/((?!_next/static|_next/image|favicon.ico|public/).*)',
  ],
}
