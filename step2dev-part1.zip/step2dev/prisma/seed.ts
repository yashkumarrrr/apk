import { PrismaClient } from '@prisma/client'
import bcrypt from 'bcryptjs'

const prisma = new PrismaClient()

async function main() {
  console.log('🌱 Seeding database...')

  // Create a test user
  const passwordHash = await bcrypt.hash('Test1234!', 12)

  const user = await prisma.user.upsert({
    where: { email: 'test@step2dev.com' },
    update: {},
    create: {
      name: 'Test User',
      email: 'test@step2dev.com',
      passwordHash,
      emailVerified: true,
      plan: 'FREE',
    },
  })

  console.log(`✅ Created test user: ${user.email}`)
  console.log('   Password: Test1234!')
  console.log('\n✅ Seeding complete!')
}

main()
  .catch((e) => {
    console.error('❌ Seed error:', e)
    process.exit(1)
  })
  .finally(async () => {
    await prisma.$disconnect()
  })
