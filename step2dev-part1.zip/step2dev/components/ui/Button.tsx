import { ButtonHTMLAttributes, forwardRef } from 'react'
import { cn } from '@/lib/utils'

interface ButtonProps extends ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: 'primary' | 'ghost' | 'danger' | 'outline'
  size?: 'sm' | 'md' | 'lg'
  loading?: boolean
  fullWidth?: boolean
}

export const Button = forwardRef<HTMLButtonElement, ButtonProps>(
  (
    {
      variant = 'primary',
      size = 'md',
      loading = false,
      fullWidth = false,
      className,
      children,
      disabled,
      ...props
    },
    ref
  ) => {
    const base =
      'inline-flex items-center justify-center font-display font-bold tracking-widest uppercase transition-all duration-200 rounded-xl disabled:opacity-50 disabled:cursor-not-allowed select-none'

    const variants = {
      primary:
        'bg-accent text-white hover:bg-accent-2 hover:shadow-[0_8px_24px_rgba(37,99,235,0.35)] hover:-translate-y-0.5 active:translate-y-0',
      ghost:
        'bg-transparent border border-border text-muted hover:border-accent hover:text-accent-2',
      danger:
        'bg-danger text-white hover:bg-red-500 hover:shadow-[0_8px_24px_rgba(239,68,68,0.3)]',
      outline:
        'bg-transparent border border-accent text-accent-2 hover:bg-accent/10',
    }

    const sizes = {
      sm: 'text-[10px] px-4 py-2 tracking-[2px]',
      md: 'text-[12px] px-6 py-[15px] tracking-[2.5px]',
      lg: 'text-[13px] px-8 py-[18px] tracking-[3px]',
    }

    return (
      <button
        ref={ref}
        disabled={disabled || loading}
        className={cn(
          base,
          variants[variant],
          sizes[size],
          fullWidth && 'w-full',
          className
        )}
        {...props}
      >
        {loading ? (
          <span className="flex items-center gap-2">
            <span className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
            Loading...
          </span>
        ) : (
          children
        )}
      </button>
    )
  }
)

Button.displayName = 'Button'
