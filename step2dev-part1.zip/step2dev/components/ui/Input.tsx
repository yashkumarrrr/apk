import { forwardRef, InputHTMLAttributes } from 'react'
import { cn } from '@/lib/utils'

interface InputProps extends InputHTMLAttributes<HTMLInputElement> {
  label?: string
  error?: string
  hint?: string
}

export const Input = forwardRef<HTMLInputElement, InputProps>(
  ({ label, error, hint, className, id, ...props }, ref) => {
    const inputId = id || label?.toLowerCase().replace(/\s/g, '-')

    return (
      <div className="w-full">
        {label && (
          <label
            htmlFor={inputId}
            className="block text-[11px] text-muted tracking-[1px] uppercase mb-1.5"
          >
            {label}
          </label>
        )}
        <input
          ref={ref}
          id={inputId}
          className={cn(
            'w-full bg-surface border rounded-xl px-5 py-[17px]',
            'font-mono text-sm text-white placeholder:text-muted',
            'outline-none transition-all duration-200',
            'focus:border-accent focus:shadow-[0_0_0_3px_rgba(37,99,235,0.15)]',
            error
              ? 'border-danger focus:border-danger focus:shadow-[0_0_0_3px_rgba(239,68,68,0.15)]'
              : 'border-border',
            className
          )}
          {...props}
        />
        {error && (
          <p className="mt-1.5 text-[12px] text-danger flex items-center gap-1.5">
            <span>⚠</span> {error}
          </p>
        )}
        {hint && !error && (
          <p className="mt-1.5 text-[12px] text-muted">{hint}</p>
        )}
      </div>
    )
  }
)

Input.displayName = 'Input'
