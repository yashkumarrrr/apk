import { cn } from '@/lib/utils'
import Link from 'next/link'

interface AuthCardProps {
  title: string
  subtitle?: string
  children: React.ReactNode
  footer?: React.ReactNode
  className?: string
}

export function AuthCard({ title, subtitle, children, footer, className }: AuthCardProps) {
  return (
    <main className="relative min-h-screen flex items-center justify-center bg-bg overflow-hidden px-4 py-12">
      {/* Grid bg */}
      <div className="absolute inset-0 grid-bg pointer-events-none" />
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] bg-accent/8 rounded-full blur-[100px] pointer-events-none" />

      <div
        className={cn(
          'relative z-10 w-full max-w-[460px]',
          'bg-surface border border-border rounded-2xl p-10',
          'shadow-[0_32px_64px_rgba(0,0,0,0.5)]',
          'animate-fade-up animate-fill-both',
          className
        )}
      >
        {/* Logo */}
        <Link href="/" className="block mb-8">
          <span className="font-display font-black text-2xl tracking-tight">AccIQ V1.0</span>
        </Link>

        {/* Header */}
        <div className="mb-8">
          <h2 className="font-display font-bold text-2xl mb-2">{title}</h2>
          {subtitle && <p className="text-muted text-sm leading-relaxed">{subtitle}</p>}
        </div>

        {/* Content */}
        <div className="space-y-4">{children}</div>

        {/* Footer */}
        {footer && <div className="mt-6 pt-6 border-t border-border">{footer}</div>}
      </div>
    </main>
  )
}
