'use client'
import { useState, Suspense } from 'react'
import { useRouter, useSearchParams } from 'next/navigation'
import Link from 'next/link'
import { AuthCard } from '@/components/auth/AuthCard'
import { Input } from '@/components/ui/Input'
import { Button } from '@/components/ui/Button'

function LoginForm() {
  const router = useRouter()
  const params = useSearchParams()
  const from = params.get('from') ?? '/dashboard'

  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')
  const [form, setForm] = useState({ email: '', password: '' })

  function onChange(e: React.ChangeEvent<HTMLInputElement>) {
    setForm(p => ({ ...p, [e.target.name]: e.target.value }))
    setError('')
  }

  async function onSubmit(e: React.FormEvent) {
    e.preventDefault()
    setLoading(true)
    setError('')
    try {
      const res = await fetch('/api/auth/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(form),
      })
      const data = await res.json()
      if (!res.ok) { setError(data.error ?? 'Invalid credentials.'); return }
      router.push(from)
      router.refresh()
    } catch {
      setError('Network error. Please try again.')
    } finally {
      setLoading(false)
    }
  }

  return (
    <AuthCard
      title="Welcome back"
      subtitle="Sign in to your AccIQ account"
      footer={
        <p className="text-center text-sm text-muted">
          No account?{' '}
          <Link href="/auth/register" className="text-accent-2 hover:underline">Create one free</Link>
        </p>
      }
    >
      <form onSubmit={onSubmit} className="space-y-4">
        {error && (
          <div className="bg-danger/10 border border-danger/30 rounded-lg px-4 py-3 text-sm text-danger">
            ⚠ {error}
          </div>
        )}
        <Input label="Email" name="email" type="email" placeholder="you@company.com"
          value={form.email} onChange={onChange} required autoComplete="email" />
        <div>
          <Input label="Password" name="password" type="password" placeholder="Your password"
            value={form.password} onChange={onChange} required autoComplete="current-password" />
          <div className="mt-2 text-right">
            <Link href="/auth/forgot-password" className="text-xs text-muted hover:text-accent-2 transition-colors">
              Forgot password?
            </Link>
          </div>
        </div>

        <Button type="submit" full loading={loading} className="py-[18px] text-[13px]">
          Sign In
        </Button>

        <div className="flex items-center gap-3">
          <div className="flex-1 h-px bg-border" />
          <span className="text-[11px] text-muted">OR</span>
          <div className="flex-1 h-px bg-border" />
        </div>

        <Button type="button" variant="ghost" full onClick={() => router.push('/dashboard?guest=1')}>
          Enter as Guest
        </Button>
      </form>
    </AuthCard>
  )
}

export default function LoginPage() {
  return <Suspense><LoginForm /></Suspense>
}
