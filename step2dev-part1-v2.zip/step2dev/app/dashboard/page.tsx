import { getCurrentUser } from '@/lib/auth'
import { redirect } from 'next/navigation'
import Link from 'next/link'

export default async function Dashboard() {
  const user = await getCurrentUser()
  if (!user) redirect('/auth/login?from=/dashboard')

  return (
    <div className="min-h-screen bg-bg font-mono">
      {/* Topbar */}
      <header className="bg-surface border-b border-border px-6 h-14 flex items-center justify-between">
        <span className="font-display font-black text-lg tracking-tight">AccIQ V1.0</span>
        <div className="flex items-center gap-4">
          {!user.emailVerified && (
            <span className="bg-warning/10 border border-warning/30 text-warning text-xs px-3 py-1 rounded-lg">
              ⚠ Verify your email
            </span>
          )}
          <span className="bg-surface-2 border border-border text-muted text-xs px-3 py-1.5 rounded-full">
            {user.name}
          </span>
          <form action="/api/auth/logout" method="POST">
            <button className="text-xs text-muted hover:text-white transition-colors">Sign out</button>
          </form>
        </div>
      </header>

      <main className="max-w-5xl mx-auto px-6 py-14">
        <div className="mb-12">
          <h1 className="font-display font-black text-4xl mb-2">
            Welcome, {user.name.split(' ')[0]} 👋
          </h1>
          <p className="text-muted text-sm">Your DevOps command center. Build Parts 2–9 to unlock everything below.</p>
        </div>

        {/* Feature cards */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 mb-12">
          {[
            { icon: '⚡', title: 'CI/CD Pipelines',     desc: 'Automate builds, tests & deploys', part: 'Part 3' },
            { icon: '📊', title: 'Monitoring',           desc: 'Real-time health & performance',   part: 'Part 5' },
            { icon: '🖥️', title: 'Server Management',   desc: 'Control infra via SSH',            part: 'Part 4' },
            { icon: '☁️', title: 'AWS Integration',     desc: 'EC2, S3, RDS in one place',        part: 'Part 6' },
            { icon: '🤖', title: 'AI Automation',       desc: 'AI-powered DevOps tasks',          part: 'Part 7' },
            { icon: '🔔', title: 'Alerts',              desc: 'Get notified before issues hit',   part: 'Part 5' },
          ].map(f => (
            <div key={f.title} className="bg-surface border border-border rounded-xl p-5 hover:border-accent/40 transition-colors group">
              <div className="text-2xl mb-3">{f.icon}</div>
              <h3 className="font-display font-bold text-base mb-1 group-hover:text-accent-2 transition-colors">{f.title}</h3>
              <p className="text-muted text-xs mb-3">{f.desc}</p>
              <span className="text-[10px] tracking-wide text-muted border border-border rounded px-2 py-0.5 uppercase">{f.part}</span>
            </div>
          ))}
        </div>

        {/* Account info */}
        <div className="bg-surface border border-border rounded-xl p-6">
          <h2 className="font-display font-bold text-lg mb-5">Your Account</h2>
          <div className="grid grid-cols-2 gap-5 text-sm">
            {[
              ['Name', user.name],
              ['Email', user.email],
              ['Plan', user.plan],
              ['Verified', user.emailVerified ? '✓ Yes' : '⚠ Pending'],
            ].map(([k, v]) => (
              <div key={k}>
                <p className="text-muted text-[11px] tracking-widest uppercase mb-1">{k}</p>
                <p className={k === 'Plan' ? 'text-accent-2 font-bold' : k === 'Verified' ? (user.emailVerified ? 'text-success' : 'text-warning') : ''}>{v}</p>
              </div>
            ))}
          </div>
        </div>
      </main>
    </div>
  )
}
