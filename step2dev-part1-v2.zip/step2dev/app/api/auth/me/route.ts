import { getCurrentUser } from '@/lib/auth'
import { ok, err } from '@/lib/utils'

export async function GET() {
  const user = await getCurrentUser()
  if (!user) return err('Not authenticated', 401)
  return ok({ user })
}
