'use client'
import { useRouter } from 'next/navigation'

export default function Landing() {
  const router = useRouter()
  return (
    <main className="relative min-h-screen flex flex-col items-center justify-center overflow-hidden bg-bg px-6">
      {/* Grid + glow */}
      <div className="absolute inset-0 grid-bg pointer-events-none" />
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] rounded-full bg-accent/10 blur-[120px] pointer-events-none" />

      <div className="relative z-10 w-full max-w-[480px] text-center">
        {/* Title */}
        <h1 className="font-display font-black text-[clamp(56px,13vw,92px)] leading-none tracking-tight mb-3 animate-fade-up fill-both">
          AccIQ V1.0
        </h1>
        <p className="text-muted text-[11px] tracking-[6px] uppercase mb-14 animate-fade-up delay-100 fill-both">
          Claim Your Spot
        </p>

        {/* CTA buttons */}
        <div className="flex flex-col gap-3 animate-fade-up delay-200 fill-both">
          <button
            onClick={() => router.push('/auth/register')}
            className="w-full py-[18px] bg-accent hover:bg-accent-2 text-white font-display font-bold text-[13px] tracking-[3px] uppercase rounded-xl transition-all duration-200 hover:shadow-[0_8px_24px_rgba(37,99,235,0.4)] hover:-translate-y-0.5 active:translate-y-0"
          >
            Save Spot
          </button>
          <button
            onClick={() => router.push('/auth/login')}
            className="w-full py-4 bg-transparent border border-border text-muted hover:border-accent hover:text-accent-2 font-mono text-[11px] tracking-[3px] uppercase rounded-xl transition-all duration-200"
          >
            Enter Via Guest Mode
          </button>
        </div>

        {/* Feature grid */}
        <div className="mt-14 grid grid-cols-2 gap-2.5 text-left animate-fade-up delay-400 fill-both">
          {[
            ['⚡', 'CI/CD Pipelines'],
            ['📊', 'Real-time Monitoring'],
            ['🖥️', 'Server Management'],
            ['☁️', 'AWS Integration'],
            ['🤖', 'AI Automation'],
            ['🔔', 'Smart Alerts'],
          ].map(([icon, label]) => (
            <div key={label} className="flex items-center gap-2.5 bg-surface border border-border rounded-lg px-3 py-2.5">
              <span className="text-sm">{icon}</span>
              <span className="text-[11px] text-muted">{label}</span>
            </div>
          ))}
        </div>
      </div>
    </main>
  )
}
