# AccIQ V1.0 — Step2Dev (Part 1)

## ⚡ Setup in 5 steps

### 1. Install dependencies
```bash
npm install
```

### 2. Set up environment
```bash
# Windows
copy .env.example .env.local

# Mac/Linux
cp .env.example .env.local
```

Open `.env.local` and fill in at minimum:
```env
DATABASE_URL="postgresql://..."   ← get free DB at neon.tech
JWT_SECRET="any-random-64-chars"  ← see below
NEXT_PUBLIC_APP_URL="http://localhost:3000"
```

**Generate JWT_SECRET:**
```bash
node -e "console.log(require('crypto').randomBytes(64).toString('hex'))"
```

### 3. Set up database
```bash
npx prisma generate
npx prisma db push
```

### 4. (Optional) Seed test user
```bash
npx ts-node --compiler-options {\"module\":\"CommonJS\"} prisma/seed.ts
# Login: test@step2dev.com / Test1234!
```

### 5. Run
```bash
npm run dev
```
Open → http://localhost:3000

---

## 🗄️ Free Database (get in 2 min)

1. Go to **https://neon.tech** → Sign up
2. Create project → Click "Connect" → Copy the `DATABASE_URL`
3. Paste into `.env.local`

---

## 📧 Email Setup

**Dev mode:** If no email provider is set, verification links print to your **terminal** — no setup needed.

**Production (Resend — free 3000/month):**
1. https://resend.com → Sign up → Create API key
2. Add to `.env.local`:
```
RESEND_API_KEY=re_xxxxx
EMAIL_FROM=AccIQ <noreply@yourdomain.com>
```

---

## 📁 File Structure
```
step2dev/
├── app/
│   ├── page.tsx                      Landing page
│   ├── layout.tsx / globals.css
│   ├── dashboard/page.tsx            Protected dashboard
│   ├── auth/
│   │   ├── login/page.tsx
│   │   ├── register/page.tsx
│   │   └── verify-email/page.tsx
│   └── api/auth/
│       ├── register/route.ts
│       ├── login/route.ts
│       ├── logout/route.ts
│       ├── me/route.ts
│       └── verify-email/route.ts
├── components/
│   ├── ui/Button.tsx + Input.tsx
│   └── auth/AuthCard.tsx
├── lib/
│   ├── auth.ts        JWT + sessions
│   ├── email.ts       Resend/SMTP/console
│   ├── prisma.ts      DB client
│   ├── utils.ts       Helpers
│   └── validations.ts Zod schemas
├── middleware.ts       Route protection + rate limiting
├── prisma/schema.prisma
└── .env.example
```

---

## 🔐 Security
- Passwords hashed with bcrypt (cost 12)
- JWT in httpOnly cookies (XSS-proof)
- Sessions stored in DB (revocable)
- Rate limiting 100 req/min per IP
- Timing-safe password compare
- Security headers on all responses

---

## 🚀 Deploy to Vercel
```bash
npm i -g vercel
vercel
# Add env vars in Vercel dashboard → Settings → Environment Variables
vercel --prod
```
